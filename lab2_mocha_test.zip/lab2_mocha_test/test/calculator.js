const chai = import('chai');
const { add } = require('../app/calculator');


const expect = chai.expect;

describe('add', () => {
  it('adds two numbers', () => {
    const result = add(2, 3);
    expect(result).to.equal(5);
  });
  it('adds two numbers', () => {
    const result = 1 + 1;
    expect(result).to.equal(2);
  });
});
